Main University Records Package
P4-DOC-009 synthetic release fixture.
No personal data.
