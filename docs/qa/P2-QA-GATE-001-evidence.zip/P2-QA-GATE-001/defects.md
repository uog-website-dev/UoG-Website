# Defect register — 2026-11-02

Build: `cd704d3f8743dafd65f91ced302a704033977c9a` (`P2-FE-010`).
All references below are local defect references ready for Azure DevOps entry,
not fabricated remote issue links. All findings remain open. Priority P1 means
a high-priority release blocker in this assessment; institutional triage may
raise it. No exception is approved.

## QA-SEC001 — P1 / High — realm claim bypasses Site authorization

**Cases:** T15, T16, T17, T35. **Automatic NO-GO.**

The approved [RBAC decision snapshot](evidence/rbac-decision.md) says Keycloak claims
authenticate identity only. Database application assignments govern resources.

Reproduction on real Keycloak/Django/PostgreSQL:

1. Dedicated QA Viewer has only Site 6 Viewer/Reviewer database assignments,
   no platform-administrator assignment, no Site 7 assignment, and no Site 7
   CMS role. The exact principal and bindings are recorded under
   `state.security_probe` in [live-results.json](evidence/live-results.json).
2. Without an elevated claim, ordinary Site A actors requesting Site B Pages
   are rejected with 403 (control request recorded).
3. Give that same dedicated identity only the Keycloak `platform-admin` realm
   role; obtain a new genuine signed access token. No database grant is added.
4. `GET /api/v1/sites/7/pages/` returns **200**.
5. `POST /api/v1/sites/7/pages/` with a new QA-only title/slug returns **201**.

Expected: 403/404, with no foreign Page created. Actual: foreign administration
read and write permitted. This does **not** claim that arbitrary unauthenticated
users can forge Keycloak tokens; it proves that an identity-provider claim
overrides the approved application permission boundary.

Source: `backend/apps/cms/api/pages.py` `_roles`/`_authorize` accepts the token
role alongside the database check. Review related claim-based shortcuts in CMS
workflow/revision services as part of the fix; those additional routes were not
all exploited in this gate. Do not generalize this finding to Menu/Core APIs,
whose normal scope checks denied foreign access in the observed tests.

Fix direction: use the common registered database permission/assignment evaluator
at every user-facing administration and workflow boundary. Add real signed-token
regressions for an actor whose realm role and database grants disagree.

Evidence: [HTTP transcript](evidence/http-transcript.json),
[principal/binding proof and actual results](evidence/live-results.json).
The temporary realm role was removed immediately; dedicated identities were
disabled, sessions logged out, DB grants revoked and CMS bindings removed later.

## QA-D001 — P1 — module administration raises transaction errors

**Cases:** T10, T11, T38.

As a real DB-granted platform administrator, obtain the resource ETag and call:

- `PATCH /api/v1/modules/11/` with `{"is_enabled":true}`;
- `POST /api/v1/sites/6/modules/11/disable/` with `{}`;
- the corresponding `enable/` action.

Expected: a transactional authorized update, or a documented validation/conflict
response. Actual: **500**, `TransactionManagementError: select_for_update cannot
be used outside of a transaction`.

Source: `backend/apps/sites/api/access.py` `AdministrationViewSet.lock` takes a
row lock; callers in `backend/apps/sites/api/views.py` Module/SiteModule actions
do not consistently open a transaction. Ordinary pytest DB wrappers can conceal
this real HTTP/autocommit defect.

Fix direction: encompass lock, ETag comparison and mutation in one approved
transaction/serialization boundary. Add autocommit/live HTTP or transaction-mode
tests. Do not drop the lock to make the error disappear.

To continue downstream testing, QA explicitly changed the trusted fixture model
switches. Those workarounds are recorded, the cases remain FAIL, and the original
global POSTS value was restored. Content enforcement itself was verified: public
POSTS returned 404 with content retained; public MENUS UI disappeared while off.

Evidence: [HTTP transcript](evidence/http-transcript.json),
[live results](evidence/live-results.json),
[public module gate](evidence/browser-module-results.json).

## QA-D002 — P1 — effective-permission inspection returns 500

**Cases:** T15; related access-management investigation T13.

Request `/api/v1/authorization/assignments/users/{qa_user_id}/effective/?scope=SITE&site=6`
as the authorized platform administrator. The Editor, Reviewer and Viewer
requests each return **500**, `NameError: name 'get_object_or_404' is not defined`.

Expected: registered effective permissions for the validated requested scope,
with ordinary authorization/validation failures handled predictably.

Source: `backend/apps/authorization/views.py`, `AssignmentViewSet.effective`.
Fix the missing dependency and exercise the actual route, including malformed
identifiers and foreign-scope requests. Existing self-permission endpoint tests
do not substitute for this assignment-specific route.

Evidence: [actual requests/results](evidence/http-transcript.json),
[case observations](evidence/live-results.json).

## QA-D003 — P1 — existing Keycloak logout configuration rejects return URI

**Case:** T12.

Actual browser authorization-code login succeeded and produced HTTP-only
Auth.js session cookies. Clicking **Sign out** reached Keycloak's
**Invalid redirect uri** page instead of returning to the signed-out console.
The browser timed out waiting for the signed-out state. Completion of IdP logout
was not proven; the gate does not infer local-cookie state from the error page.

Runtime `admin-web` allowed post-logout URI attribute:

```text
http://localhost:3001/admin/*+http://localhost/admin/*
```

The repository realm definition uses the `##` separator instead. This is an
**existing-environment configuration drift/reconciliation defect**, not proof
that a newly imported realm necessarily has the same value.

Source/config: `frontend/apps/admin-web/src/app/actions.ts` and
`infrastructure/keycloak/realm-import/uog-realm.json` (`admin-web`). Reconcile
approved logout URIs on existing realms and repeat full login/logout. Do not
replace the allowlist with an unrestricted redirect wildcard.

Evidence: [logout failure screenshot](evidence/T12-logout-failure.png),
[browser run](evidence/browser-results.json),
[safe runtime attribute capture](evidence/cleanup.json).

## QA-D004 — P1 — authenticated access-management UI omits real grants

**Case:** T13.

The dedicated account successfully used its explicit DB platform-administrator
grant to create Site role assignments over HTTP. The same account's real
Next.js access-control screen displayed **No effective permissions are granted
for your platform scope** and **No roles are visible to this account**, with
empty role/permission tables. Loading a shell is not successful management.

The initial browser smoke recorded T13 as shell-load PASS. Functional artifact
review supersedes that limited result: final T13 is FAIL. Investigate the active
BFF/server-action contract and error handling; root cause has not been reduced
to a single call and is not asserted to be identical to D002.

Evidence: [authenticated access screen](evidence/admin-access.png),
[authenticated dashboard](evidence/admin-authenticated.png),
[actual role assignment requests](evidence/http-transcript.json).

## QA-D005 — P1 — regression/typecheck gates are not green

**Case:** T37.

- Backend default regression: **626 passed, 1 failed, 2 skipped**. Failure:
  `apps/cms/tests/test_module.py::test_cms_mounts_scoped_workflow_revision_admin_and_public_routes`;
  expected route-name set omits implemented `content-workflow-history`.
  Update the intended contract test rather than deleting a legitimate endpoint.
- Admin frontend: **257 passed, 32 failed, 12 unhandled errors** across 4 failed
  test files. Repeated `SiteMenusPanel` failures access
  `navigation.data.inheritance.length` on incompatible/undefined data in tests.
  Determine which failures are stale mocks versus real implementation errors;
  the run cannot be accepted as green either way.
- Shared UI: **86 passed**; API client: **157 passed**.
- Typecheck exits 2: **13 Admin diagnostics**, including missing access action
  exports, missing `apiBaseUrl` props, Post list-query typing and incomplete
  `PublicPageDocument` preview values. Four other typecheck tasks succeeded.

Evidence: [backend JUnit](evidence/backend.junit.xml),
[backend execution](evidence/backend-regression.log),
[frontend execution](evidence/frontend-tests.log),
[typecheck](evidence/frontend-typecheck.log).
No remote Azure CI result or pipeline URL was available; local failure is not
misrepresented as a fetched remote CI result. Actual browser probes are evidence
for selected flows, not a comprehensive CI E2E suite.

## QA-GAP001 — P2 / acceptance gap — draft/public coexistence not demonstrated

**Case:** T23 (BLOCKED).

Attempting to edit the published Page through the authoring PATCH endpoint
returned **400**, while the public snapshot retained its previous title. That
proves rejection/stability, not creation and editing of a new concurrent draft.
No approved alternative draft-fork API flow was demonstrated. Confirm/document
the intended workflow or implement it and repeat the test. Do not remove a
published-content protection rule as a shortcut.

Evidence: [live T23 observation](evidence/live-results.json),
[Page PATCH/public reads](evidence/http-transcript.json).

## Follow-up execution order

1. Fix SEC001 and add signed-token/DB-scope disagreement regressions.
2. Fix transactional module management and effective-permission route errors.
3. Reconcile logout configuration; repair access UI and regression/typecheck gates.
4. Execute T23 with the approved draft workflow and run T38 in an isolated fresh
   stack. Preserve the current development data rather than wiping its volumes.
5. Re-run all 38 cases without fixture workarounds, link remote CI and defect
   resolutions, then obtain actual QA Lead/Technical Lead/Product Owner decisions.
